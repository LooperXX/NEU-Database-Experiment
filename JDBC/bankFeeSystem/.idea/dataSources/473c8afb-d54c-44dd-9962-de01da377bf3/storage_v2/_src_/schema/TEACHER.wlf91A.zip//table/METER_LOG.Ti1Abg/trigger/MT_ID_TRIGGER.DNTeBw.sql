create trigger MT_ID_TRIGGER
  before insert
  on METER_LOG
  for each row
  when (NEW.MT_ID is null)
  begin
	  select MT_ID_SEQUENCE.nextval into :NEW.MT_ID from dual;
	end;
/

