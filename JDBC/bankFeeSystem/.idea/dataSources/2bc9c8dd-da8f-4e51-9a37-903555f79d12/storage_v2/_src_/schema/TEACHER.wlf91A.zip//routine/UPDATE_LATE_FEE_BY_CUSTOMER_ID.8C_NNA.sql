create PROCEDURE UPDATE_LATE_FEE_BY_CUSTOMER_ID(in_customer_id IN  CUSTOMER.CUSTOMER_ID%TYPE) AS
  TYPE Ref_cursor_type IS REF CURSOR;
  TYPE Pr_id_array IS VARRAY (10) OF NUMBER(9);
  residentCurRatio_   CODE_TABLE.C_VALUE%TYPE; -- 居民当年违约金比例
  residentCrossRatio_ CODE_TABLE.C_VALUE%TYPE; -- 居民跨年违约金比例
  cropCurRatio_       CODE_TABLE.C_VALUE%TYPE; -- 企业当年违约金比例
  cropCrossRatio_     CODE_TABLE.C_VALUE%TYPE;-- 企业跨年违约金比例
  pr_id_query_sql    VARCHAR2(200);
  pr_id_array_       Pr_id_array;
  pr_id_cursor       Ref_cursor_type;
  pr_id_temp         POWER_RATE_LIST.PR_ID%TYPE;
  payable_date_      POWER_RATE_LIST.PAYABLE_DATE%TYPE;
  date_delta         NUMBER;
  late_fee_          POWER_RATE_LIST.LATE_FEE%TYPE := 0;
  actual_fee_        POWER_RATE_LIST.ACTUAL_FEE%TYPE;
  paid_fee_          POWER_RATE_LIST.PAID_FEE%TYPE;
  -- 设备游标
  CURSOR device_cursor IS
    SELECT DEVICE_ID, DEVICE_TYPE
    FROM DEVICE
    WHERE DEVICE.CUSTOMER_ID = in_customer_id;

  -- 设备记录
  TYPE Device_rec IS RECORD (
  device_id DEVICE.DEVICE_ID%TYPE,
  device_type DEVICE.DEVICE_TYPE%TYPE
  );

  -- 设备记录的集合
  TYPE Device_rec_array IS VARRAY (10) OF Device_rec;

  device_rec_        Device_rec;
  device_rec_array_  Device_rec_array;
  i                  NUMBER := 1;
  k                  NUMBER := 1;
  BEGIN
    device_rec_array_ := Device_rec_array(); -- 初始化
    pr_id_array_ := Pr_id_array();
    OPEN device_cursor;
    LOOP
      FETCH device_cursor INTO device_rec_;
      EXIT WHEN device_cursor%NOTFOUND;
      device_rec_array_.extend(1);
      device_rec_array_(i) := device_rec_;
      i := i + 1;
    END LOOP;
    CLOSE device_cursor;
    SELECT C_VALUE INTO residentCurRatio_ FROM CODE_TABLE WHERE C_KEY = '居民当年违约金比例';
    SELECT C_VALUE INTO residentCrossRatio_ FROM CODE_TABLE WHERE C_KEY = '居民跨年违约金比例';
    SELECT C_VALUE INTO cropCurRatio_ FROM CODE_TABLE WHERE C_KEY = '企业当年违约金比例';
    SELECT C_VALUE INTO cropCrossRatio_ FROM CODE_TABLE WHERE C_KEY = '企业跨年违约金比例';
    IF device_rec_array_.COUNT = 0 THEN 
      NULL;
    ELSE
      FOR j IN device_rec_array_.FIRST..device_rec_array_.LAST LOOP
        pr_id_query_sql := ('SELECT PR_ID FROM POWER_RATE_LIST WHERE DEVICE_ID = ' || device_rec_array_(j).device_id || 'AND PAY_STATE != 1');
        OPEN pr_id_cursor for pr_id_query_sql;
        LOOP
          FETCH pr_id_cursor INTO pr_id_temp;
          EXIT WHEN pr_id_cursor%NOTFOUND;
          pr_id_array_.extend(1);
          pr_id_array_(k) := pr_id_temp;
          k := k + 1;
      END LOOP;
      EXIT WHEN pr_id_array_.COUNT = 0;
      FOR p IN pr_id_array_.FIRST..pr_id_array_.LAST LOOP
        SELECT PAYABLE_DATE,PAID_FEE INTO payable_date_,paid_fee_
        FROM POWER_RATE_LIST
        WHERE PR_ID = pr_id_array_(p);
        late_fee_ := 0;
        date_delta := TO_DATE(SYSDATE) - TO_DATE(payable_date_);
        IF (date_delta > 0) -- 应缴日期已过
        THEN
          late_fee_ := (CASE device_rec_array_(j).device_type
                       WHEN 01
                         THEN TO_NUMBER(residentCurRatio_) * date_delta * paid_fee_
                       WHEN 02
                         THEN TO_NUMBER(cropCurRatio_) * date_delta * paid_fee_
                       ELSE 0 END);
        END IF;

        date_delta := (TO_DATE(SYSDATE) - (ADD_MONTHS(TRUNC(TO_DATE(payable_date_), 'yyyy'), 12) - 1));
        IF (date_delta > 0) -- 欠费跨年
        THEN late_fee_ := late_fee_ + (CASE device_rec_array_(j).device_type
                                     WHEN 01
                                       THEN (TO_NUMBER(residentCrossRatio_) - TO_NUMBER(residentCurRatio_)) * date_delta * paid_fee_
                                     WHEN 02
                                       THEN (TO_NUMBER(cropCrossRatio_) - TO_NUMBER(cropCurRatio_)) * date_delta * paid_fee_
                                     ELSE 0 END);
        END IF;
        UPDATE POWER_RATE_LIST
        SET LATE_FEE = late_fee_
        WHERE PR_ID = pr_id_array_(p);
        UPDATE POWER_RATE_LIST
        SET ACTUAL_FEE = PAID_FEE + LATE_FEE
        WHERE PR_ID = pr_id_array_(p);
        COMMIT ;-- 提交更新
      END LOOP;
    END LOOP;
    CLOSE pr_id_cursor;
    END IF;
    
  END UPDATE_LATE_FEE_BY_CUSTOMER_ID;
/

