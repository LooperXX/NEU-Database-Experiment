create PACKAGE package_power_rate_list_cursor
AS

   TYPE power_rate_list_cursor IS REF CURSOR;--定义游标类型
   --定义存储过程
   PROCEDURE QUERY_LIST_BY_CUSTOMER_ID(IN_CUSTOMER_ID IN CUSTOMER.CUSTOMER_ID%TYPE,power_rate_list_ OUT power_rate_list_cursor);

END package_power_rate_list_cursor;
/

