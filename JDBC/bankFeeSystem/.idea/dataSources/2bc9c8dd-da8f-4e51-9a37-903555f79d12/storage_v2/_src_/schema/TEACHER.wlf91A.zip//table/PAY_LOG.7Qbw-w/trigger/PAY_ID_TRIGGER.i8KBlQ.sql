create trigger PAY_ID_TRIGGER
  before insert
  on PAY_LOG
  for each row
  when (NEW.PAY_ID is null)
  begin
	  select PAY_ID_SEQUENCE.nextval into :NEW.PAY_ID from dual;
	end;
/

