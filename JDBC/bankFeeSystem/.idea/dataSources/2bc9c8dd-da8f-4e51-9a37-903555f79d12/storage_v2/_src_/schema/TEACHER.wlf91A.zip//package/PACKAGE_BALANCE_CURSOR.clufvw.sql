create PACKAGE package_balance_cursor
AS

   TYPE balance_cursor IS REF CURSOR;--定义游标类型
   --定义存储过程
   PROCEDURE QUERY_BALANCE_BY_CUSTOMER_ID(IN_CUSTOMER_ID IN CUSTOMER.CUSTOMER_ID%TYPE,balance_ OUT balance_cursor);

END package_balance_cursor;
/

