create trigger DEVICE_ID_TRIGGER
  before insert
  on DEVICE
  for each row
  when (NEW.DEVICE_ID is null)
  begin
	  select DEVICE_ID_SEQUENCE.nextval into :NEW.DEVICE_ID from dual;
	end;
/

