create trigger AE_ID_TRIGGER
  before insert
  on ACCOUNT_ERROR_DETAILS
  for each row
  when (NEW.AE_ID is null)
  begin
	  select AE_ID_SEQUENCE.nextval into :NEW.AE_ID from dual;
	end;
/

