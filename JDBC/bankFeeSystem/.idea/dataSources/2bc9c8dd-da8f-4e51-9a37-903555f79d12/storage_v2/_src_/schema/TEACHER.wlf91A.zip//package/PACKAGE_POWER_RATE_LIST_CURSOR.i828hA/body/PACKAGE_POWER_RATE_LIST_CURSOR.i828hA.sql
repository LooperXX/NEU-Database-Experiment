create PACKAGE BODY package_power_rate_list_cursor AS

  PROCEDURE QUERY_LIST_BY_CUSTOMER_ID(IN_CUSTOMER_ID IN CUSTOMER.CUSTOMER_ID%TYPE,power_rate_list_ OUT power_rate_list_cursor)
  AS
  BEGIN
      OPEN power_rate_list_ FOR
      SELECT * FROM POWER_RATE_LIST
      WHERE POWER_RATE_LIST.CUSTOMER_ID=IN_CUSTOMER_ID
      ORDER BY MT_DATE;
  END QUERY_LIST_BY_CUSTOMER_ID;

END package_power_rate_list_cursor;
/

