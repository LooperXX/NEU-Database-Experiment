create trigger BALANCE_ID_TRIGGER
  before insert
  on BALANCE
  for each row
  when (NEW.BALANCE_ID is null)
  begin
  select BALANCE_ID_SEQUENCE.nextval into :NEW.BALANCE_ID from dual;
end;
/

