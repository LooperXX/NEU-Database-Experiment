create PROCEDURE INSERT_NEW_BANK_CARD(IN_BANK_ID IN BANK.BANK_ID%TYPE,
                                                IN_CUSTOMER_ID IN CUSTOMER.CUSTOMER_ID%TYPE) AS
  in_customer_id_error          EXCEPTION;
  in_bank_id_error              EXCEPTION;
  bank_name_                    BANK.BANK_NAME%TYPE;
  customer_name_                CUSTOMER.CUSTOMER_NAME%TYPE;
  card_id                       BANK_CARD.CARD_ID%TYPE;
  BEGIN
    BEGIN
      SELECT BANK_NAME INTO bank_name_ FROM BANK WHERE BANK_ID = IN_BANK_ID;
      EXCEPTION WHEN NO_DATA_FOUND THEN
        RAISE in_bank_id_error;
    END;
    BEGIN
      SELECT CUSTOMER_NAME INTO customer_name_ FROM CUSTOMER WHERE CUSTOMER_ID = IN_CUSTOMER_ID;
      EXCEPTION WHEN NO_DATA_FOUND THEN
        RAISE in_customer_id_error;
    END;
    INSERT INTO BANK_CARD (BANK_ID, CUSTOMER_ID) VALUES (IN_BANK_ID,IN_CUSTOMER_ID);
    SELECT CARD_ID_SEQUENCE.currval INTO card_id from dual;
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('[SUCCESS]新建用户' || customer_name_ || '的' || bank_name_ || '的银行卡' || card_id || '成功');
    EXCEPTION
      WHEN in_customer_id_error THEN
        DBMS_OUTPUT.PUT_LINE('[ERROR]输入用户ID不存在，新建失败');
      WHEN in_bank_id_error THEN
        DBMS_OUTPUT.PUT_LINE('[ERROR]输入银行ID不存在，新建失败');
  END;
/

