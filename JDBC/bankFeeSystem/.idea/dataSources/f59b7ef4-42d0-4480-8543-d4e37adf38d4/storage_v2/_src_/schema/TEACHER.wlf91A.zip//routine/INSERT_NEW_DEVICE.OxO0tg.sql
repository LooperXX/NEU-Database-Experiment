create PROCEDURE INSERT_NEW_DEVICE(IN_CUSTOMER_ID IN CUSTOMER.CUSTOMER_ID%TYPE,
                                                IN_DEVICE_TYPE IN DEVICE.DEVICE_TYPE%TYPE,
                                                IN_DEVICE_NAME IN DEVICE.DEVICE_NAME%TYPE) AS
  in_customer_id_error          EXCEPTION;
  device_type_error          EXCEPTION;
  device_id_                DEVICE.DEVICE_ID%TYPE;
  customer_name_            CUSTOMER.CUSTOMER_NAME%TYPE;
  BEGIN
    BEGIN
      SELECT CUSTOMER_NAME INTO customer_name_ FROM CUSTOMER WHERE CUSTOMER_ID = IN_CUSTOMER_ID;
      EXCEPTION WHEN NO_DATA_FOUND THEN 
        RAISE in_customer_id_error;     
    END;
    IF IN_DEVICE_TYPE != '01' AND IN_DEVICE_TYPE != '02' THEN
      RAISE device_type_error;
    END IF;
    INSERT INTO DEVICE (CUSTOMER_ID, DEVICE_TYPE, DEVICE_NAME) VALUES (IN_CUSTOMER_ID,IN_DEVICE_TYPE,IN_DEVICE_NAME);
    SELECT DEVICE_ID_SEQUENCE.currval INTO device_id_ from dual;
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('[SUCCESS]新建用户' || customer_name_ || '的电表' || device_id_ || '成功');
    EXCEPTION 
      WHEN in_customer_id_error THEN
        DBMS_OUTPUT.PUT_LINE('[ERROR]输入用户ID不存在，新建失败');
      WHEN device_type_error THEN
        DBMS_OUTPUT.PUT_LINE('[ERROR]新电表类型异常，新建失败');
  END;
/

