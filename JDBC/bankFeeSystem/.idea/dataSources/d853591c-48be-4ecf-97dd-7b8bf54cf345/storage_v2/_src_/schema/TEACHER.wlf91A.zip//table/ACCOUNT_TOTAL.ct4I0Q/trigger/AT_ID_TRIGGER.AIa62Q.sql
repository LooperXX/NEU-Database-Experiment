create trigger AT_ID_TRIGGER
  before insert
  on ACCOUNT_TOTAL
  for each row
  when (NEW.AT_ID is null)
  begin
	  select AT_ID_SEQUENCE.nextval into :NEW.AT_ID from dual;
	end;
/

