create trigger CUSTOMER_ID_TRIGGER
  before insert
  on CUSTOMER
  for each row
  when (NEW.CUSTOMER_ID is null)
  begin
	  select CUSTOMER_ID_SEQUENCE.nextval into :NEW.CUSTOMER_ID from dual;
	end;
/

