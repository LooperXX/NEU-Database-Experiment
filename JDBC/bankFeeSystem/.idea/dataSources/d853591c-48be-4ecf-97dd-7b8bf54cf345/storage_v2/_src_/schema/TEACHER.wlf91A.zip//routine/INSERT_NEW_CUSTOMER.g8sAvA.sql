create PROCEDURE INSERT_NEW_CUSTOMER(IN_CUSTOMER_NAME IN CUSTOMER.CUSTOMER_NAME%TYPE,
                                                   IN_ADDRESS IN CUSTOMER.ADDRESS%TYPE,
                                                   IN_BALANCE IN CUSTOMER.BALANCE%TYPE,
                                                   IN_PSWORD IN CUSTOMER.PSWORD%TYPE) AS
  balance_xiaoyuling          EXCEPTION;
  customer_id_                CUSTOMER.CUSTOMER_ID%TYPE;
  BEGIN
    IF IN_BALANCE < 0 THEN
      RAISE balance_xiaoyuling;
    END IF;
    INSERT INTO CUSTOMER (CUSTOMER_NAME, ADDRESS, BALANCE, PSWORD) VALUES (IN_CUSTOMER_NAME,IN_ADDRESS,IN_BALANCE,IN_PSWORD);
    SELECT CUSTOMER_ID_SEQUENCE.currval INTO customer_id_ from dual;
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('[SUCCESS]新建用户' || customer_id_ || '成功');
    EXCEPTION WHEN balance_xiaoyuling THEN
      DBMS_OUTPUT.PUT_LINE('[ERROR]新建用户的余额不可小于零');
  END;
/

