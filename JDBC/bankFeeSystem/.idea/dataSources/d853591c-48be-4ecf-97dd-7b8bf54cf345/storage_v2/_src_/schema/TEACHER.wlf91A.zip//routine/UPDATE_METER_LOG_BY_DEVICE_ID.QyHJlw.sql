create PROCEDURE UPDATE_METER_LOG_BY_DEVICE_ID(IN_DEVICE_ID IN DEVICE.DEVICE_ID%TYPE,
                                                             IN_MT_DATE IN METER_LOG.MT_DATE%TYPE,
                                                             IN_MT_NUMBER IN METER_LOG.MT_NUMBER%TYPE,
                                                             IN_MR_ID IN METER_LOG.MR_ID%TYPE,
                                                             OUT_RES OUT VARCHAR2) IS
  CURSOR DEVICE_PR IS
    SELECT PR_ID FROM POWER_RATE_LIST WHERE DEVICE_ID = IN_DEVICE_ID AND PAY_STATE != '1' ORDER BY MT_DATE ASC;
  --变量
  MT_NUMBER_EXCEPTION   EXCEPTION ;
  device_type_          DEVICE.DEVICE_TYPE%TYPE;
  device_name_          DEVICE.DEVICE_NAME%TYPE;
  pricePerKwh_          CODE_TABLE.C_VALUE%TYPE;
  begin_number_         POWER_RATE_LIST.BEGIN_NUMBER%TYPE;
  end_number_           POWER_RATE_LIST.END_NUMBER%TYPE;
  basic_cost_           POWER_RATE_LIST.BASIC_COST%TYPE := 0.00;
  additional_cost1_     POWER_RATE_LIST.ADDITIONAL_COST_1%TYPE := 0.00;
  additional_cost2_     POWER_RATE_LIST.ADDITIONAL_COST_2%TYPE := 0.00;
  paid_fee_             POWER_RATE_LIST.PAID_FEE%TYPE := 0.00;
  actual_fee_           POWER_RATE_LIST.ACTUAL_FEE%TYPE := 0.00;
  late_fee_             POWER_RATE_LIST.LATE_FEE%TYPE := 0.00;
  pay_date_             POWER_RATE_LIST.PAY_DATE%TYPE := NULL;
  already_fee_          POWER_RATE_LIST.ALREADY_FEE%TYPE := 0.00;
  pay_state_            POWER_RATE_LIST.PAY_STATE%TYPE := 0;
  pr_id_                POWER_RATE_LIST.PR_ID%TYPE;
  balance_before        CUSTOMER.BALANCE%TYPE;
  balance_now           CUSTOMER.BALANCE%TYPE;
  customer_id_          CUSTOMER.CUSTOMER_ID%TYPE;
  fee_wait_             POWER_RATE_LIST.ALREADY_FEE%TYPE;

  BEGIN
    SELECT DEVICE_TYPE,DEVICE_NAME,CUSTOMER_ID INTO device_type_,device_name_,customer_id_ FROM DEVICE WHERE DEVICE_ID = IN_DEVICE_ID;
    SELECT C_VALUE INTO pricePerKwh_ FROM CODE_TABLE WHERE C_KEY = '每度电价格';
    UPDATE_LATE_FEE_BY_CUSTOMER_ID(customer_id_);
    BEGIN
      --找到上次的电表度数记录
      SELECT MT_NUMBER INTO begin_number_ FROM METER_LOG WHERE DEVICE_ID = IN_DEVICE_ID AND ROWNUM = 1 ORDER BY MT_DATE DESC;
    EXCEPTION WHEN NO_DATA_FOUND THEN
      --首次抄表
      begin_number_ := 0;
    END;
    --验证
    end_number_ := IN_MT_NUMBER;
    IF begin_number_ > end_number_
      THEN
        RAISE MT_NUMBER_EXCEPTION;
    END IF;
    --插入新的抄表记录
    INSERT INTO METER_LOG (MT_DATE,DEVICE_ID,CUSTOMER_ID,MT_NUMBER,MR_ID) VALUES (IN_MT_DATE,IN_DEVICE_ID,customer_id_,IN_MT_NUMBER,IN_MR_ID);
    IF begin_number_ = end_number_ THEN
      --读数不变的情况
      INSERT INTO POWER_RATE_LIST (DEVICE_ID,CUSTOMER_ID,MT_DATE,BEGIN_NUMBER,END_NUMBER,BASIC_COST,
                                   ADDITIONAL_COST_1,ADDITIONAL_COST_2,PAID_FEE,ACTUAL_FEE,LATE_FEE,PAYABLE_DATE,PAY_DATE,ALREADY_FEE,PAY_STATE)
      VALUES (IN_DEVICE_ID,customer_id_,IN_MT_DATE,begin_number_,end_number_,
              basic_cost_,additional_cost1_,additional_cost2_,paid_fee_,
              actual_fee_,late_fee_,ADD_MONTHS(IN_MT_DATE,1),pay_date_,already_fee_,'1');
      DBMS_OUTPUT.PUT_LINE('[SUCCESS] 您已成功更新抄表记录，该电表读数不变');
      OUT_RES := '[SUCCESS] 您已成功更新抄表记录，该电表读数不变';
    ELSE
      --计算相关金额
      basic_cost_ := TO_NUMBER(pricePerKwh_) * (end_number_ - begin_number_);
      additional_cost1_ := basic_cost_ * 0.08;
      CASE device_type_
        WHEN '01'
          THEN
            additional_cost2_ := basic_cost_ * 0.10;
        WHEN '02'
          THEN
            additional_cost2_ := basic_cost_ * 0.15;
      END CASE;
      paid_fee_ := basic_cost_+ additional_cost1_ + additional_cost2_;
      actual_fee_ := paid_fee_;
      --检查余额
      SELECT BALANCE INTO balance_before FROM CUSTOMER WHERE CUSTOMER_ID = customer_id_;

      --插入电费清单
      INSERT INTO POWER_RATE_LIST (DEVICE_ID,CUSTOMER_ID,MT_DATE,BEGIN_NUMBER,END_NUMBER,BASIC_COST,
                                   ADDITIONAL_COST_1,ADDITIONAL_COST_2,PAID_FEE,ACTUAL_FEE,LATE_FEE,PAYABLE_DATE,PAY_DATE,ALREADY_FEE,PAY_STATE)
      VALUES (IN_DEVICE_ID,customer_id_,IN_MT_DATE,begin_number_,end_number_,
              basic_cost_,additional_cost1_,additional_cost2_,paid_fee_,
              actual_fee_,late_fee_,ADD_MONTHS(IN_MT_DATE,1),pay_date_,already_fee_,pay_state_);
      --更新余额表与用户表
      IF balance_before > 0 THEN
        balance_now := balance_before;
        OPEN DEVICE_PR;
        LOOP
          FETCH DEVICE_PR INTO pr_id_;
          EXIT WHEN DEVICE_PR%NOTFOUND;
          EXIT WHEN balance_now = 0;
          SELECT (ACTUAL_FEE - ALREADY_FEE) INTO fee_wait_ FROM POWER_RATE_LIST WHERE PR_ID = pr_id_;
          IF fee_wait_ > balance_now THEN
            UPDATE POWER_RATE_LIST
            SET PAY_STATE   = '2',
                PAY_DATE    = IN_MT_DATE,
                ALREADY_FEE = ALREADY_FEE + balance_now
            WHERE PR_ID = pr_id_;
            INSERT INTO BALANCE (CUSTOMER_ID,BALANCE_TYPE,BALANCE_DELTA,PR_ID) VALUES (customer_id_,'2',balance_now,pr_id_);
            UPDATE CUSTOMER SET BALANCE = 0 WHERE CUSTOMER_ID = customer_id_;
            balance_now := 0;
          ELSE
            UPDATE POWER_RATE_LIST
            SET PAY_STATE   = '1',
                PAY_DATE    = IN_MT_DATE,
                ALREADY_FEE = ALREADY_FEE + fee_wait_
            WHERE PR_ID = pr_id_;
            INSERT INTO BALANCE (CUSTOMER_ID,BALANCE_TYPE,BALANCE_DELTA,PR_ID) VALUES (customer_id_,'2',fee_wait_,pr_id_);
            UPDATE CUSTOMER SET BALANCE = BALANCE - fee_wait_ WHERE CUSTOMER_ID = customer_id_;
            balance_now := balance_now - fee_wait_;
          END IF;
        END LOOP;
        CLOSE DEVICE_PR;
        DBMS_OUTPUT.PUT_LINE('[SUCCESS] 您已成功更新设备ID为'|| IN_DEVICE_ID || '的抄表记录，并从余额中自动扣除了'|| (balance_before - balance_now) ||'元');
        OUT_RES := '[SUCCESS] 您已成功更新设备ID为'|| IN_DEVICE_ID || '的抄表记录，并从余额中自动扣除了'|| (balance_before - balance_now) ||'元';
      ELSE
        DBMS_OUTPUT.PUT_LINE('[SUCCESS] 您已成功更新设备ID为'|| IN_DEVICE_ID || '的抄表记录');
        OUT_RES := '[SUCCESS] 您已成功更新设备ID为'|| IN_DEVICE_ID || '的抄表记录';
      END IF;
    END IF;
    COMMIT;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      DBMS_OUTPUT.PUT_LINE('[ERROR] 您输入的设备号不存在');
      OUT_RES := '[ERROR] 您输入的设备号不存在';
    WHEN MT_NUMBER_EXCEPTION THEN
      DBMS_OUTPUT.PUT_LINE('[ERROR] 您输入的电表读数小于上月读数，输入失败');
      OUT_RES := '[ERROR] 您输入的电表读数小于上月读数，输入失败';
  END UPDATE_METER_LOG_BY_DEVICE_ID;
/

