create trigger BT_ID_TRIGGER
  before insert
  on BANK_TRANSFER_RECORD
  for each row
  when (NEW.BT_ID is null)
  begin
	  select BT_ID_SEQUENCE.nextval into :NEW.BT_ID from dual;
	end;
/

