create trigger CARD_ID_TRIGGER
  before insert
  on BANK_CARD
  for each row
  when (NEW.CARD_ID is null)
  begin
	  select CARD_ID_SEQUENCE.nextval into :NEW.CARD_ID from dual;
	end;
/

