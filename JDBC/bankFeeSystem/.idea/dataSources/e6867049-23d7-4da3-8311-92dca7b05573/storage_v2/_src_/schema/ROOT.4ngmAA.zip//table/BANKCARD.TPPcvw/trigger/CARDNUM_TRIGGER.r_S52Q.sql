create trigger CARDNUM_TRIGGER
  before insert
  on BANKCARD
  for each row
  when (NEW.CARDNUM is null)
  begin
  select CLIENTID_SEQUENCE.nextval into :NEW.CARDNUM from dual;
end;
/

