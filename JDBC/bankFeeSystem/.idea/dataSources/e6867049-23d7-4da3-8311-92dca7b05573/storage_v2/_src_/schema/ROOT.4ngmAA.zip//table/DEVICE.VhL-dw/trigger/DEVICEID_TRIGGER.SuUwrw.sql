create trigger DEVICEID_TRIGGER
  before insert
  on DEVICE
  for each row
  when (NEW.DEVICEID is null)
  begin
  select DEVICEID_SEQUENCE.nextval into :NEW.DEVICEID from dual;
end;
/

