create trigger CHECKID_TRIGGER
  before insert
  on CHECK_TOTAL
  for each row
  when (NEW.CHECKID is null)
  begin
  select CLIENTID_SEQUENCE.nextval into :NEW.CHECKID from dual;
end;
/

