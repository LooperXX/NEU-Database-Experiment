create trigger CLIENTID_TRIGGER
  before insert
  on CLIENT
  for each row
  when (NEW.CLIENTID is null)
  begin
  select CLIENTID_SEQUENCE.nextval into :NEW.CLIENTID from dual;
end;
/

