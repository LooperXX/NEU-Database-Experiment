create trigger BANKID_TRIGGER
  before insert
  on BANK
  for each row
  when (NEW.BANKID is null)
  begin
  select CLIENTID_SEQUENCE.nextval into :NEW.BANKID from dual;
end;
/

