create trigger EXCEPTIONID_TRIGGER
  before insert
  on CHECK_EXCEPTION
  for each row
  when (NEW.EXCEPTIONID is null)
  begin
  select CLIENTID_SEQUENCE.nextval into :NEW.EXCEPTIONID from dual;
end;
/

