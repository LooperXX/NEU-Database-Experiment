create trigger RECEIVABLEID_TRIGGER
  before insert
  on COST_RECEIVABLE
  for each row
  when (NEW.RECEIVABLEID is null)
  begin
  select CLIENTID_SEQUENCE.nextval into :NEW.RECEIVABLEID from dual;
end;
/

