create trigger RECORDID_TRIGGER
  before insert
  on RECORD_BANK
  for each row
  when (NEW.RECORDID is null)
  begin
  select CLIENTID_SEQUENCE.nextval into :NEW.RECORDID from dual;
end;
/

