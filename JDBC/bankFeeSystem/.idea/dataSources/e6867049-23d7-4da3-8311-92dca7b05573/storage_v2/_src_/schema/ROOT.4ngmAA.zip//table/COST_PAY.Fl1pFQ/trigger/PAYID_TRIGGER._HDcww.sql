create trigger PAYID_TRIGGER
  before insert
  on COST_PAY
  for each row
  when (NEW.PAYID is null)
  begin
  select CLIENTID_SEQUENCE.nextval into :NEW.PAYID from dual;
end;
/

