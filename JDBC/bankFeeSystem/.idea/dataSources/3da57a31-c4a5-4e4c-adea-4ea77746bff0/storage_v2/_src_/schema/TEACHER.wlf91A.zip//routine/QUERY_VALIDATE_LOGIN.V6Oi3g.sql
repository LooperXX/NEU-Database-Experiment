create PROCEDURE QUERY_VALIDATE_LOGIN(IN_USER_ID IN CUSTOMER.CUSTOMER_ID%TYPE,
                                                    IN_USER_PASSWORD IN CUSTOMER.PSWORD%TYPE,
                                                    IN_USER_TYPE IN NUMBER,
                                                    OUT_RESULT OUT VARCHAR2,
                                                    OUT_NAME OUT CUSTOMER.CUSTOMER_NAME%TYPE) AS
  BEGIN
    OUT_RESULT := 'WRONG';
    CASE IN_USER_TYPE
      WHEN '1' THEN
        BEGIN
          SELECT CUSTOMER_NAME INTO OUT_NAME FROM CUSTOMER WHERE CUSTOMER_ID = IN_USER_ID AND PSWORD = IN_USER_PASSWORD;
          OUT_RESULT := 'RIGHT';
          EXCEPTION WHEN NO_DATA_FOUND  THEN
            OUT_RESULT := 'WRONG';
        END;
      WHEN '2' THEN
        BEGIN
          SELECT MR_NAME INTO OUT_NAME FROM METER_READER WHERE MR_ID = IN_USER_ID AND PSWORD = IN_USER_PASSWORD;
          OUT_RESULT := 'RIGHT';
          EXCEPTION WHEN NO_DATA_FOUND  THEN
          OUT_RESULT := 'WRONG';
        END;
      WHEN '3' THEN
        BEGIN
          IF IN_USER_ID = 4999 AND IN_USER_PASSWORD = '4999' THEN
            OUT_NAME := '管理员';
            OUT_RESULT := 'RIGHT';
          ELSE
            OUT_RESULT := 'WRONG';
          END IF;
        END;
    END CASE;
  END;
/

