create trigger PR_ID_TRIGGER
  before insert
  on POWER_RATE_LIST
  for each row
  when (NEW.PR_ID is null)
  begin
	  select PR_ID_SEQUENCE.nextval into :NEW.PR_ID from dual;
	end;
/

