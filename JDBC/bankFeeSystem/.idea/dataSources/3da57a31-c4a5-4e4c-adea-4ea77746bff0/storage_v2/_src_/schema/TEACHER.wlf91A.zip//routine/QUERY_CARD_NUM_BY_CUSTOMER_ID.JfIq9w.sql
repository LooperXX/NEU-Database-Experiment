create PROCEDURE QUERY_CARD_NUM_BY_CUSTOMER_ID(IN_CUSTOMER_ID IN CUSTOMER.CUSTOMER_ID%TYPE,
                                                             OUT_RES OUT VARCHAR2)AS
  bank_card_rec         BANK_CARD%ROWTYPE;
  CURSOR card_num_cursor IS
    SELECT * FROM BANK_CARD
        WHERE CUSTOMER_ID = IN_CUSTOMER_ID;
  BEGIN
    OPEN card_num_cursor;
    LOOP
      FETCH card_num_cursor INTO bank_card_rec;
      EXIT WHEN card_num_cursor%NOTFOUND;
      OUT_RES := OUT_RES || bank_card_rec.BANK_ID || ',' || bank_card_rec.CARD_ID || ';';
    END LOOP;
    CLOSE card_num_cursor;
  END;
/

