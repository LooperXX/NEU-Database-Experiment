create PROCEDURE CHECK_BY_DATE(IN_BANK_ID IN BANK.BANK_ID%TYPE,
                                             IN_CHECK_DATE IN DATE,
                                             OUT_RES OUT VARCHAR2) AS

  bank_count_                     ACCOUNT_TOTAL.BANK_COUNT%TYPE;
  bank_amount_                    ACCOUNT_TOTAL.BANK_AMOUNT%TYPE;
  enterprise_count_               ACCOUNT_TOTAL.ENTERPRISE_COUNT%TYPE;
  enterprise_amount_              ACCOUNT_TOTAL.ENTERPRISE_AMOUNT%TYPE;
  is_success_                     ACCOUNT_TOTAL.IS_SUCCESS%TYPE;
  bt_rec_                         BANK_TRANSFER_RECORD%ROWTYPE;
  pay_log_rec_                    PAY_LOG%ROWTYPE;
  pay_log_correct_rec_            PAY_LOG%ROWTYPE;
  bt_id_                          BANK_TRANSFER_RECORD.BT_ID%TYPE;
  pay_id_                         PAY_LOG.PAY_ID%TYPE;
  transfer_amount_                BANK_TRANSFER_RECORD.TRANSFER_AMOUNT%TYPE;
  pay_amount_                     PAY_LOG.PAY_AMOUNT%TYPE;
  absence_bank_amount             ACCOUNT_TOTAL.BANK_AMOUNT%TYPE := 0.00;
  absence_bank_count              ACCOUNT_TOTAL.BANK_COUNT%TYPE := 0;
  absence_enterprise_count        ACCOUNT_TOTAL.ENTERPRISE_COUNT%TYPE := 0;
  absence_enterprise_amount       ACCOUNT_TOTAL.ENTERPRISE_AMOUNT%TYPE := 0.00;
  correct_count_                  NUMBER := 0;

  CURSOR bt_rec_cursor IS
    SELECT * FROM BANK_TRANSFER_RECORD
      WHERE BANK_ID = IN_BANK_ID AND TO_DATE(TRANSFER_TIME) = IN_CHECK_DATE
      ORDER BY BT_ID;

  CURSOR pay_log_rec_cursor IS
    SELECT * FROM PAY_LOG
      WHERE BANK_ID = IN_BANK_ID AND TO_DATE(PAY_TIME) = IN_CHECK_DATE AND PAY_TYPE != '02'
      ORDER BY PAY_ID;

  CURSOR pay_log_correct_rec_cursor IS
    SELECT * FROM PAY_LOG
      WHERE BANK_ID = IN_BANK_ID AND TO_DATE(PAY_TIME) = IN_CHECK_DATE AND PAY_TYPE = '02'
      ORDER BY PAY_ID;

  BEGIN
    --对总账
    SELECT SUM(TRANSFER_AMOUNT),COUNT(BT_ID) INTO bank_amount_,bank_count_ FROM BANK_TRANSFER_RECORD
      WHERE BANK_ID = IN_BANK_ID AND TO_DATE(TRANSFER_TIME) = IN_CHECK_DATE;

    SELECT SUM(PAY_AMOUNT),COUNT(PAY_ID) INTO enterprise_amount_,enterprise_count_ FROM PAY_LOG
      WHERE BANK_ID = IN_BANK_ID AND TO_DATE(PAY_TIME) = IN_CHECK_DATE AND PAY_TYPE != '02';
    DBMS_OUTPUT.PUT_LINE('银行总金额: ' || bank_amount_ || '   银行总笔数: '  || bank_count_);
    OUT_RES := bank_amount_ || ';'  || bank_count_ || ';';
    DBMS_OUTPUT.PUT_LINE('公司总金额: ' || enterprise_amount_ || '   公司总笔数: ' || enterprise_count_);
    OUT_RES := OUT_RES || enterprise_amount_ || ';' || enterprise_count_ || ';';
    IF bank_amount_ = enterprise_amount_ AND bank_count_ = enterprise_count_ THEN
      is_success_ := '00';
      OUT_RES := OUT_RES || '00' || ';';
      DBMS_OUTPUT.PUT_LINE('[SUCCESS]对总账结束，'|| TO_CHAR(IN_CHECK_DATE,'yyyy-mm-dd') || '日两账单无异常');
      OUT_RES := OUT_RES || '[SUCCESS]对总账结束，'|| TO_CHAR(IN_CHECK_DATE,'yyyy-mm-dd') || '日两账单无异常';
    ELSE
      is_success_ := '01';
      OUT_RES := OUT_RES || '01' || ';';
      DBMS_OUTPUT.PUT_LINE('[ERROR]对总账结束，'|| TO_CHAR(IN_CHECK_DATE,'yyyy-mm-dd') || '日两账单出现异常，执行对明细账操作');
      OUT_RES := OUT_RES || '[ERROR]对总账结束，'|| TO_CHAR(IN_CHECK_DATE,'yyyy-mm-dd') || '日两账单出现异常，执行对明细账操作'|| ';';
    END IF;
    INSERT INTO ACCOUNT_TOTAL (ACCOUNT_DATE, BANK_ID, BANK_COUNT, BANK_AMOUNT, ENTERPRISE_COUNT, ENTERPRISE_AMOUNT, IS_SUCCESS)
      VALUES  (IN_CHECK_DATE,IN_BANK_ID,bank_count_,bank_amount_,enterprise_count_,enterprise_amount_,is_success_);
    --对明细账
    IF is_success_ = '01' THEN
      --情况一 已转账 未缴费 即银行缺失
      OPEN pay_log_rec_cursor;
      LOOP
        FETCH pay_log_rec_cursor INTO pay_log_rec_;
        EXIT WHEN pay_log_rec_cursor%NOTFOUND;
        BEGIN
          SELECT TRANSFER_AMOUNT INTO transfer_amount_ FROM BANK_TRANSFER_RECORD WHERE BT_ID = pay_log_rec_.BT_ID;
          EXCEPTION
          --找到银行缺失的记录
            WHEN NO_DATA_FOUND THEN
              INSERT INTO ACCOUNT_ERROR_DETAILS (ACCOUNT_TIME, BANK_ID, BT_ID, CUSTOMER_ID, ERROR_TYPE, PAY_ID)
                VALUES (IN_CHECK_DATE,IN_BANK_ID,pay_log_rec_.BT_ID,pay_log_rec_.CUSTOMER_ID,'0',pay_log_rec_.PAY_ID);
              absence_bank_count := absence_bank_count + 1;
              absence_bank_amount := absence_bank_amount + pay_log_rec_.PAY_AMOUNT;
        END;
      END LOOP;
      CLOSE pay_log_rec_cursor;
      DBMS_OUTPUT.PUT_LINE('[INFO]找到了' || absence_bank_count || '条银行缺失的缴费记录');
      OUT_RES := OUT_RES || '[INFO]找到了' || absence_bank_count || '条银行缺失的缴费记录' || ';';

      IF (bank_amount_ + absence_bank_amount) = enterprise_amount_ AND (bank_count_ + absence_bank_count) = enterprise_count_ THEN
        OUT_RES := OUT_RES || '[SUCCESS]对明细账操作完成' || ';';
      ELSE
        --情况二 未转账 已缴费 即公司缺失
        OPEN bt_rec_cursor;
        LOOP
          FETCH bt_rec_cursor INTO bt_rec_;
          EXIT WHEN bt_rec_cursor%NOTFOUND;
          BEGIN
            SELECT PAY_AMOUNT INTO pay_amount_ FROM PAY_LOG WHERE BT_ID = bt_rec_.BT_ID AND PAY_TYPE != '02';
            EXCEPTION
            --找到公司缺失的记录
              WHEN NO_DATA_FOUND THEN
                INSERT INTO ACCOUNT_ERROR_DETAILS (ACCOUNT_TIME, BANK_ID, BT_ID, CUSTOMER_ID, ERROR_TYPE)
                  VALUES (IN_CHECK_DATE,IN_BANK_ID,bt_rec_.BT_ID,bt_rec_.CUSTOMER_ID,'1');
                absence_enterprise_count := absence_enterprise_count + 1;
                absence_enterprise_amount := absence_enterprise_amount + bt_rec_.TRANSFER_AMOUNT;
          END;
        END LOOP;
        CLOSE pay_log_rec_cursor;
        OUT_RES := OUT_RES || '[INFO]找到了' || absence_enterprise_count || '条公司缺失的缴费记录' || ';';

        IF (bank_amount_ + absence_bank_amount) = (enterprise_amount_ + absence_enterprise_amount)
           AND (bank_count_ + absence_bank_count) = (enterprise_count_ + absence_enterprise_count) THEN
          OPEN pay_log_correct_rec_cursor;
          LOOP
            FETCH pay_log_correct_rec_cursor INTO pay_log_correct_rec_;
            EXIT WHEN pay_log_correct_rec_cursor%NOTFOUND;
            correct_count_ := correct_count_ + 1;
            INSERT INTO ACCOUNT_ERROR_DETAILS (ACCOUNT_TIME, BANK_ID, BT_ID, CUSTOMER_ID, ERROR_TYPE, PAY_ID)
               VALUES (IN_CHECK_DATE,IN_BANK_ID,pay_log_correct_rec_.BT_ID,pay_log_correct_rec_.CUSTOMER_ID,'2',pay_log_correct_rec_.PAY_ID);
          END LOOP;
          CLOSE pay_log_correct_rec_cursor;
          DBMS_OUTPUT.PUT_LINE('[INFO]找到了' || correct_count_ || '条冲正的缴费记录');
          OUT_RES := OUT_RES || '[SUCCESS]对明细账操作完成' || ';';
        ELSE
          DBMS_OUTPUT.PUT_LINE('[ERROR]对明细账操作出现异常，debug吧少年:<');
          OUT_RES := 'NO';
        END IF;
      END IF;
    END IF;
    COMMIT;
    EXCEPTION WHEN NO_DATA_FOUND THEN
      DBMS_OUTPUT.PUT_LINE('[ERROR]您输入的日期或银行ID有误');
      OUT_RES := 'NO';
  END CHECK_BY_DATE;
/

