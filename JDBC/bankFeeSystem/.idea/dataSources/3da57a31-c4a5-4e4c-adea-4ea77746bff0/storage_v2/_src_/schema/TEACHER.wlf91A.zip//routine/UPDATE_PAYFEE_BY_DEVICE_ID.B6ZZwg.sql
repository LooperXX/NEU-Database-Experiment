create PROCEDURE UPDATE_PAYFEE_BY_DEVICE_ID (IN_DEVICE_ID IN DEVICE.DEVICE_ID%TYPE,
                                             IN_FEE IN POWER_RATE_LIST.PAID_FEE%TYPE,
                                             IN_CUSTOMER_ID IN CUSTOMER.CUSTOMER_ID%TYPE,
                                             IN_CARD_ID IN BANK_CARD.CARD_ID%TYPE,
                                             OUT_RES OUT VARCHAR2) AS
--变量表
  pr_id_temp          POWER_RATE_LIST.PR_ID%TYPE;
  fee_wait            POWER_RATE_LIST.PAID_FEE%TYPE;
  balance_before      CUSTOMER.BALANCE%TYPE; -- 用户缴费前余额
  balance_before_      CUSTOMER.BALANCE%TYPE; -- 用户缴费前余额
  balance_now         CUSTOMER.BALANCE%TYPE;
  bank_id_            BANK.BANK_ID%TYPE;
  bt_id_              BANK_TRANSFER_RECORD.BT_ID%TYPE;
  pay_id_             PAY_LOG.PAY_ID%TYPE;
  notes_              PAY_LOG.NOTES%TYPE := '';
  pay_state_          POWER_RATE_LIST.PAY_STATE%TYPE;
  counts              NUMBER := 0;
  device_name_        DEVICE.DEVICE_NAME%TYPE;
  fee_error           EXCEPTION ;
  customer_id_error   EXCEPTION ;
  card_id_error       EXCEPTION ;

  --游标选出所有待缴费记录 并升序排列
  CURSOR list_cursor IS
    SELECT PR_ID FROM POWER_RATE_LIST
    WHERE DEVICE_ID = IN_DEVICE_ID AND PAY_STATE != 1
    ORDER BY MT_DATE ASC;

  BEGIN
    SELECT DEVICE_NAME INTO device_name_ FROM DEVICE  WHERE DEVICE_ID = IN_DEVICE_ID;
    --初始化余额和银行ID
    BEGIN
      SELECT BALANCE INTO balance_before FROM CUSTOMER WHERE CUSTOMER_ID = IN_CUSTOMER_ID;
      balance_before_ := balance_before;
      balance_now := balance_before + IN_FEE;
    EXCEPTION WHEN NO_DATA_FOUND THEN
      RAISE customer_id_error;
    END;
    BEGIN
      SELECT BANK_ID INTO bank_id_ FROM BANK_CARD WHERE CARD_ID = IN_CARD_ID AND CUSTOMER_ID = IN_CUSTOMER_ID;
    EXCEPTION WHEN NO_DATA_FOUND THEN
      RAISE card_id_error;
    END;
    IF IN_FEE <=0 THEN
      RAISE fee_error;
    END IF;
    --更新该用户滞纳金
    UPDATE_LATE_FEE_BY_CUSTOMER_ID(IN_CUSTOMER_ID);
    --获得该设备的所有待缴费账单号
    OPEN list_cursor;
    LOOP
      --总余额不足 则退出循环
      EXIT WHEN balance_now <= 0.00;

      FETCH list_cursor INTO pr_id_temp;
      EXIT WHEN list_cursor%NOTFOUND;
      SELECT (ACTUAL_FEE - ALREADY_FEE) INTO fee_wait
      FROM POWER_RATE_LIST
      WHERE PR_ID = pr_id_temp;

      --修改余额表
      IF balance_before >= fee_wait THEN
        balance_before := balance_before - fee_wait;
        INSERT INTO BALANCE (CUSTOMER_ID, BALANCE_TYPE, BALANCE_DELTA, PR_ID) VALUES (IN_CUSTOMER_ID,'2',fee_wait,pr_id_temp);
      --如果余额不足支付 扣光余额
      ELSIF balance_before < fee_wait AND balance_before > 0 THEN
        INSERT INTO BALANCE (CUSTOMER_ID, BALANCE_TYPE, BALANCE_DELTA, PR_ID) VALUES (IN_CUSTOMER_ID,'2',balance_before,pr_id_temp);
        balance_before := 0;
      ELSE
        NULL;
      END IF;
      --更新本次支付状态
      IF fee_wait <= balance_now THEN
        pay_state_ := '1';
        balance_now := balance_now - fee_wait;
      ELSE
        pay_state_ := '2';
        fee_wait := balance_now;
        balance_now := 0.00;
      END IF;
      --保存账单号以及金额
      notes_ := notes_ || pr_id_temp || ',' || fee_wait || ';';
      --修改电费清单
      UPDATE POWER_RATE_LIST
      SET PAY_STATE   = pay_state_,
          PAY_DATE    = SYSDATE,
          ALREADY_FEE = ALREADY_FEE + fee_wait
      WHERE PR_ID = pr_id_temp;
      counts := counts + 1;
    END LOOP;
    CLOSE list_cursor;

    --更新账户余额
    UPDATE CUSTOMER SET BALANCE = balance_now WHERE CUSTOMER_ID = IN_CUSTOMER_ID;
    --修改银行记录表
    INSERT INTO BANK_TRANSFER_RECORD (BANK_ID,CUSTOMER_ID,TRANSFER_AMOUNT,TRANSFER_TIME,CARD_ID)
    VALUES (bank_id_,IN_CUSTOMER_ID,IN_FEE,SYSDATE,IN_CARD_ID);
    SELECT BT_ID_SEQUENCE.currval INTO bt_id_ FROM dual;

    --修改缴费日志
    INSERT INTO PAY_LOG (CUSTOMER_ID,PAY_TIME,PAY_AMOUNT,PAY_TYPE,BANK_ID,BT_ID,NOTES)
    VALUES(IN_CUSTOMER_ID,SYSDATE,IN_FEE,'01',bank_id_,bt_id_,notes_);
    SELECT PAY_ID_SEQUENCE.currval INTO pay_id_ FROM dual;

    --若缴费还有剩余 转入余额并记录
    IF counts = 0 THEN
      INSERT INTO BALANCE (CUSTOMER_ID, BALANCE_TYPE, BALANCE_DELTA, PAY_ID, BT_ID) VALUES (IN_CUSTOMER_ID,'1',IN_FEE,pay_id_,bt_id_);
      DBMS_OUTPUT.PUT_LINE('[SUCCESS]该设备无待缴费账单，直接转入账户余额 ' || IN_FEE || '元');
      OUT_RES := '[SUCCESS]该设备无待缴费账单，直接转入账户余额 ' || IN_FEE || '元';
    ELSE
      IF balance_before_ = 0 THEN   --
        IF balance_now > 0 THEN     --
          INSERT INTO BALANCE (CUSTOMER_ID, BALANCE_TYPE, BALANCE_DELTA, PAY_ID, BT_ID) VALUES (IN_CUSTOMER_ID,'1',balance_now,pay_id_,bt_id_);
          DBMS_OUTPUT.PUT_LINE('[SUCCESS]缴费成功，共缴费'|| (IN_FEE - balance_now) || '元，并转入账户余额 ' || balance_now || '元');
          OUT_RES := '[SUCCESS]缴费成功，共缴费'|| (IN_FEE - balance_now) || '元，并转入账户余额 ' || balance_now || '元';
        ELSE                        --
          DBMS_OUTPUT.PUT_LINE('[SUCCESS]缴费成功，共缴费'|| IN_FEE || '元');
          OUT_RES := '[SUCCESS]缴费成功，共缴费'|| IN_FEE || '元';
        END IF;
      ELSE                          --
        IF balance_before_ < balance_now THEN
          IF balance_now >= IN_FEE THEN
            INSERT INTO BALANCE (CUSTOMER_ID, BALANCE_TYPE, BALANCE_DELTA, PAY_ID, BT_ID) VALUES (IN_CUSTOMER_ID,'1',IN_FEE,pay_id_,bt_id_);
            DBMS_OUTPUT.PUT_LINE('[SUCCESS]缴费成功，共缴费'|| (IN_FEE + balance_before_ - balance_now) || '元，并转入账户余额' || IN_FEE || '元');
            OUT_RES := '[SUCCESS]缴费成功，共缴费'|| (IN_FEE + balance_before_ - balance_now) || '元，并转入账户余额' || IN_FEE || '元';
          ELSE
            INSERT INTO BALANCE (CUSTOMER_ID, BALANCE_TYPE, BALANCE_DELTA, PAY_ID, BT_ID) VALUES (IN_CUSTOMER_ID,'1',balance_now,pay_id_,bt_id_);
            DBMS_OUTPUT.PUT_LINE('[SUCCESS]缴费成功，共缴费'|| (IN_FEE + balance_before_ - balance_now) || '元，并转入账户余额 ' || balance_now || '元');
            OUT_RES := '[SUCCESS]缴费成功，共缴费'|| (IN_FEE + balance_before_ - balance_now) || '元，并转入账户余额 ' || balance_now || '元';
          END IF;
        ELSIF balance_before >= balance_now THEN
          DBMS_OUTPUT.PUT_LINE('[SUCCESS]缴费成功，共缴费'|| (IN_FEE + balance_before_ - balance_now) || '元');
          OUT_RES := '[SUCCESS]缴费成功，共缴费'|| (IN_FEE + balance_before_ - balance_now) || '元';
        END IF;
      END IF;
    END IF;
    --提交事务
    COMMIT;
    EXCEPTION WHEN NO_DATA_FOUND THEN
      DBMS_OUTPUT.PUT_LINE('[ERROR]您输入的设备号不存在');
      OUT_RES := 'NO';
      WHEN card_id_error THEN
        DBMS_OUTPUT.PUT_LINE('[ERROR]你输入的卡号不存在或不属于您');
      WHEN fee_error THEN
        DBMS_OUTPUT.PUT_LINE('[ERROR]您的缴费金额应当大于0');
      WHEN customer_id_error THEN
        DBMS_OUTPUT.PUT_LINE('[ERROR]您输入的用户ID有误');
    END UPDATE_PAYFEE_BY_DEVICE_ID;
/

