create PROCEDURE QUERY_DEVICE_ID_BY_CUSTOMER_ID(IN_CUSTOMER_ID IN CUSTOMER.CUSTOMER_ID%TYPE,
                                                             OUT_RES OUT VARCHAR2)AS
  device_id_rec         DEVICE%ROWTYPE;
  CURSOR device_id_cursor IS
    SELECT * FROM DEVICE
        WHERE CUSTOMER_ID = IN_CUSTOMER_ID;
  BEGIN
    OPEN device_id_cursor;
    LOOP
      FETCH device_id_cursor INTO device_id_rec;
      EXIT WHEN device_id_cursor%NOTFOUND;
      OUT_RES := OUT_RES || device_id_rec.DEVICE_ID || ',' || device_id_rec.DEVICE_NAME || ';';
    END LOOP;
    CLOSE device_id_cursor;
  END;
/

