create PROCEDURE GET_ERROR_DETAIL(IN_CHECK_DATE IN ACCOUNT_ERROR_DETAILS.ACCOUNT_TIME%TYPE,
                                    IN_BANK_ID IN BANK.BANK_ID%TYPE,
                                    OUT_RES OUT VARCHAR2)AS
  CURSOR error_rec_cursor IS
    SELECT * FROM ACCOUNT_ERROR_DETAILS
        WHERE TO_DATE(ACCOUNT_TIME) = TO_DATE(IN_CHECK_DATE) AND BANK_ID = IN_BANK_ID;
  error_rec                ACCOUNT_ERROR_DETAILS%ROWTYPE;
  BEGIN
    OPEN error_rec_cursor;
    LOOP
      FETCH error_rec_cursor INTO error_rec;
      EXIT WHEN error_rec_cursor%NOTFOUND;
      OUT_RES := OUT_RES || error_rec.AE_ID || ',' || error_rec.CUSTOMER_ID || ',' || error_rec.ERROR_TYPE || ',' || error_rec.BT_ID
        || ',' || error_rec.PAY_ID || ';';
    END LOOP;
    CLOSE error_rec_cursor;
  END GET_ERROR_DETAIL;
/

